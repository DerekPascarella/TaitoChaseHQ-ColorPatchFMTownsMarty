:: Chase H.Q. (FM Towns Marty)
:: Color Palette Fix
::
:: Written by Derek Pascarella (ateam)

@echo off

setlocal DisableDelayedExpansion

:: Set terminal window size
mode con:cols=72 lines=39 >nul 2>&1
cls
title Chase H.Q. - Color Palette Fix

:: Welcome message
type tools\banner.txt
echo.
echo                        __________________________
echo                  __,--^|    Color Palette Fix     ^|--,__
echo                    '--^|      FM Towns Marty      ^|--'
echo                        ``````````````````````````
echo.
echo Initiating patching process...
echo.

:: Define paths.
set "original_folder=redump_original"
set "patched_folder=patched_disc_image_cue_bin"
set "ccd_folder=patched_disc_image_ccd_img_sub"
set "target_file=Taito Chase H.Q. (Japan) (Track 01).bin"
set "patch_folder=xdelta"
set "patch_file=Chase H.Q. (Marty Color Palette Fix).xdelta"
set "tools_folder=tools"
set "xdelta_exe=xdelta.exe"

:: Perform sanity check.
echo Performing sanity check...
echo.

if not exist "%original_folder%" (
    echo Error: Folder "%original_folder%" does not exist.
    echo.
    goto End
)

if not exist "%original_folder%\%target_file%" (
    echo Error: File "%target_file%" does not exist in %original_folder%" folder.
    echo.
    goto End
)

if not exist "%tools_folder%" (
    echo Error: Folder "%tools_folder%" does not exist.
    echo.
    goto End
)

if not exist "%tools_folder%\%xdelta_exe%" (
    echo Error: File "%xdelta_exe%" does not exist in %tools_folder%" folder.
    echo.
    goto End
)

if not exist "%patch_folder%\%patch_file%" (
    echo Error: File "%patch_file%" does not exist in %patch_folder%" folder.
    echo.
    goto End
)

:: Clean up old files.
echo Cleaning up old files....
echo.
del /q "%patched_folder%\*" > nul 2>&1
del /q "%ccd_folder%\*" > nul 2>&1

:: Copy original disc image to patched folder.
echo Copying all files from "%original_folder%" to
echo "%patched_folder%"...
echo.

xcopy "%original_folder%\*" "%patched_folder%\" /S /I /Y > nul 2>&1
if errorlevel 1 (
	echo Error: Failed to copy files to "%patched_folder%" folder.
	echo.
	goto End
)

echo Files copied successfully.
echo.

:: Apply XDelta patch.
echo Applying patch...
echo.

"%tools_folder%\%xdelta_exe%" -f -d -s "%original_folder%\%target_file%" "%patch_folder%\%patch_file%" "%patched_folder%\%target_file%" > nul 2>&1
if errorlevel 1 (
	echo Error: Failed to apply the XDelta patch.
	echo.
	goto End
)

echo Patch applied successfully.
echo.

:: CUE/BIN completion message.
echo Patched CUE/BIN disc image is located in the
echo "%patched_folder%" folder.
echo.

:: Generate CCD/IMG/SUB formatted disc image
echo Creating CCD/IMG/SUB version of patched disc image...
echo.

:: Create output folder
if not exist "%ccd_folder%" (
    mkdir "%ccd_folder%"
)

:: Run cue-2-ccd.exe on the patched disc image.
for %%F in ("%patched_folder%\*.cue") do (
    "%tools_folder%\cue-2-ccd.exe" "%%~fF" "%ccd_folder%" >nul
    if errorlevel 1 (
        echo ERROR: Failed to generate CCD/IMG/SUB disc image from %%F
        goto End
    )
)

:: Completion message
echo Patched CCD/IMG/SUB disc image is located in the
echo "%ccd_folder%" folder.
echo.
echo Patching process completed successfully.
echo.
:End
echo Press any key to close this window...
pause > nul

endlocal
